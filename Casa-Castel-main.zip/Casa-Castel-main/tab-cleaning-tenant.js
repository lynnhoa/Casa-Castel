/* ─────────────────────────────────────────────────────────────
   CASA CASTEL v2 — ABSENCE MANAGEMENT
   js/tab-absence.js

   Single source of truth for all absence functionality.
   Loaded in both landlord.html and tenant.html.
   Writes to kitchen_absences table — shared by kitchen and
   cleaning tabs for rotation strip state.

   Public API:
     absOpenModal(name)       — 'register' or 'list'
     absCloseModal(name)
   Depends on: constants.js, supabase-client.js, utils.js
   ───────────────────────────────────────────────────────────── */

/* ── INJECT MODAL HTML ──────────────────────────────────────── */
(function _absInjectModals() {
  const wrap = document.createElement('div');
  wrap.id = 'absence-modals';
  wrap.innerHTML = `
    <!-- Register absence modal (tenant only) -->
    <div class="cc-modal-overlay" id="absence-modal-register" onclick="if(event.target===this)absCloseModal('register')">
      <div class="cc-modal-sheet" style="max-height:80vh;">
        <div class="cc-modal-hdr">
          <span class="cc-modal-title">Register absence</span>
          <button class="cc-modal-close" onclick="absCloseModal('register')">✕</button>
        </div>
        <div class="cc-modal-body">
          <div id="abs-room-pill" style="display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:500;padding:3px 10px;border-radius:8px;background:var(--cc-notice-bg);border:0.5px solid var(--cc-notice-bdr);color:var(--cc-notice-text);margin-bottom:14px;"></div>
          <p style="font-size:9px;font-weight:600;letter-spacing:0.1em;text-transform:uppercase;color:var(--cc-taupe);margin-bottom:6px;">Dates</p>
          <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:14px;">
            <div style="display:flex;align-items:center;gap:10px;">
              <p style="font-size:11px;color:var(--cc-taupe);width:36px;flex-shrink:0;">From</p>
              <input type="date" id="abs-from" style="flex:1;min-width:0;height:40px;border:0.5px solid var(--cc-rule);border-radius:var(--cc-r-sm);padding:0 10px;font-size:12px;color:var(--cc-taupe);background:var(--cc-white);font-family:inherit;"/>
            </div>
            <div style="display:flex;align-items:center;gap:10px;">
              <p style="font-size:11px;color:var(--cc-taupe);width:36px;flex-shrink:0;">To</p>
              <input type="date" id="abs-to" style="flex:1;min-width:0;height:40px;border:0.5px solid var(--cc-rule);border-radius:var(--cc-r-sm);padding:0 10px;font-size:12px;color:var(--cc-taupe);background:var(--cc-white);font-family:inherit;"/>
            </div>
          </div>
          <p style="font-size:9px;font-weight:600;letter-spacing:0.1em;text-transform:uppercase;color:var(--cc-taupe);margin-bottom:6px;">Note (optional)</p>
          <textarea id="abs-note" rows="2" placeholder="e.g. holiday, work trip…" style="width:100%;border:0.5px solid var(--cc-rule);border-radius:var(--cc-r-sm);padding:8px 10px;font-size:12px;color:var(--cc-ink);background:var(--cc-white);font-family:inherit;resize:none;margin-bottom:14px;"></textarea>
          <p id="abs-error" style="font-size:11px;color:#7A2020;margin-bottom:8px;display:none;"></p>
          <button id="abs-save" style="width:100%;height:42px;background:var(--cc-notice-bg);border:0.5px solid var(--cc-notice-bdr);border-radius:var(--cc-r-sm);color:var(--cc-notice-text);font-size:11px;font-weight:500;letter-spacing:0.06em;cursor:pointer;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:6px;">
            <i class="ti ti-calendar-plus" style="font-size:14px;" aria-hidden="true"></i>
            Save absence
          </button>
        </div>
      </div>
    </div>

    <!-- All absences list modal (tenant + landlord) -->
    <div class="cc-modal-overlay" id="absence-modal-list" onclick="if(event.target===this)absCloseModal('list')">
      <div class="cc-modal-sheet" style="max-height:75vh;">
        <div class="cc-modal-hdr">
          <span class="cc-modal-title">Absences</span>
          <button class="cc-modal-close" onclick="absCloseModal('list')">✕</button>
        </div>
        <div class="cc-modal-body">
          <div id="abs-list-body"><p class="cc-note">Loading…</p></div>
          <div id="abs-list-add" style="margin-top:14px;display:none;">
            <button onclick="absCloseModal('list');absOpenModal('register');" style="width:100%;height:40px;background:var(--cc-notice-bg);border:0.5px solid var(--cc-notice-bdr);border-radius:var(--cc-r-sm);color:var(--cc-notice-text);font-size:11px;font-weight:500;cursor:pointer;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:5px;">
              <i class="ti ti-plus" style="font-size:14px;" aria-hidden="true"></i>
              Add absence
            </button>
          </div>
        </div>
      </div>
    </div>
  `;
  document.body.appendChild(wrap);

  /* Wire from-date change → update to-date min */
  document.getElementById('abs-from')?.addEventListener('change', e => {
    const toEl = document.getElementById('abs-to');
    if (toEl) { toEl.min = e.target.value; if (toEl.value < e.target.value) toEl.value = e.target.value; }
  });

  /* Wire save button */
  document.getElementById('abs-save')?.addEventListener('click', absSaveAbsence);
})();

/* ── ROLE DETECTION ─────────────────────────────────────────── */
function _absRole() { return localStorage.getItem('cc_role') || 'tenant'; }
function _absMyRoom() {
  return (typeof currentRoom !== 'undefined' ? currentRoom : '') || localStorage.getItem('cc_room') || '';
}

/* ── OPEN / CLOSE ───────────────────────────────────────────── */
function absOpenModal(name) {
  document.getElementById('absence-modal-' + name)?.classList.add('open');
  if (name === 'list') _absPopulateList();
  if (name === 'register') {
    const myRoom = _absMyRoom();
    const pill = document.getElementById('abs-room-pill');
    if (pill) pill.textContent = myRoom;
    // Pre-fill to next Mon–Sun
    const today = new Date();
    const day = today.getDay();
    const daysToMon = day === 0 ? 1 : 8 - day;
    const nextMon = new Date(today); nextMon.setDate(today.getDate() + daysToMon);
    const nextSun = new Date(nextMon); nextSun.setDate(nextMon.getDate() + 6);
    const fmt = d => d.toISOString().slice(0,10);
    const today10 = fmt(today);
    const fromEl = document.getElementById('abs-from');
    const toEl   = document.getElementById('abs-to');
    if (fromEl) { fromEl.min = today10; fromEl.value = fmt(nextMon); }
    if (toEl)   { toEl.min = fmt(nextMon); toEl.value = fmt(nextSun); }
    const errEl = document.getElementById('abs-error');
    if (errEl) errEl.style.display = 'none';
    const noteEl = document.getElementById('abs-note');
    if (noteEl) noteEl.value = '';
  }
}
function absCloseModal(name) {
  document.getElementById('absence-modal-' + name)?.classList.remove('open');
}

/* ── LIST POPULATOR ─────────────────────────────────────────── */
async function _absPopulateList() {
  const el = document.getElementById('abs-list-body');
  const addBtn = document.getElementById('abs-list-add');
  if (!el) return;
  if (!sbL) { el.innerHTML = '<p class="cc-note">Connect Supabase.</p>'; return; }
  const isLandlord = _absRole() === 'landlord';
  // Show Add button for tenants only
  if (addBtn) addBtn.style.display = isLandlord ? 'none' : '';
  const { data } = await sbL.from('kitchen_absences').select('*').order('from_date', { ascending: true });
  if (!data || !data.length) { el.innerHTML = '<p class="cc-note">No absences registered.</p>'; return; }
  const fmtD = s => { const [y,m,d] = s.split('-'); return `${d}.${m}.${y}`; };
  // Current cleaning week dates for "this week" indicator
  const curIdx = typeof _hcWeekIndex === 'function' ? _hcWeekIndex(new Date()) : -1;
  const curInfo = curIdx >= 0 && typeof _hcWeekInfo === 'function' ? _hcWeekInfo(curIdx) : null;
  const curStart = curInfo ? curInfo.start.toISOString().slice(0,10) : null;
  const curEnd   = curInfo ? curInfo.end.toISOString().slice(0,10)   : null;
  const badge = `<span style="font-size:9px;font-weight:500;padding:2px 8px;border-radius:8px;background:#F5EEE8;border:0.5px solid #D4A87A;color:#8C5A30;white-space:nowrap;flex-shrink:0;">Away</span>`;
  el.innerHTML = data.map(a => {
    const overlaps = curStart && a.from_date <= curEnd && a.to_date >= curStart;
    const thisWeek = overlaps ? `<span style="font-size:10px;color:#8C5A30;margin-left:4px;">· this week</span>` : '';
    const note = a.note ? ` · <span style="color:var(--cc-stone);">${esc(a.note)}</span>` : '';
    const canDelete = isLandlord || a.room === _absMyRoom();
    return `<div style="display:flex;align-items:flex-start;justify-content:space-between;padding:9px 0;border-bottom:0.5px solid var(--cc-rule);">
      <div style="flex:1;min-width:0;">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:2px;">${badge}<span style="font-size:13px;font-weight:500;color:var(--cc-ink);">${esc(a.room)}</span>${thisWeek}</div>
        <div style="font-size:11px;color:var(--cc-taupe);">${fmtD(a.from_date)} – ${fmtD(a.to_date)}${note}</div>
      </div>
      ${canDelete ? `<button onclick="absDeleteAbsence('${a.id}')" style="font-size:11px;color:var(--cc-stone);background:none;border:none;cursor:pointer;padding:4px;flex-shrink:0;">✕</button>` : ''}
    </div>`;
  }).join('');
}

/* ── SAVE (tenant only, with merge) ─────────────────────────── */
let _absSaveBusy = false;
async function absSaveAbsence() {
  if (_absSaveBusy) return; _absSaveBusy = true;
  try {
    if (!sbL) return;
    const myRoom  = _absMyRoom();
    const fromVal = document.getElementById('abs-from')?.value;
    const toVal   = document.getElementById('abs-to')?.value;
    const noteRaw = document.getElementById('abs-note')?.value.trim() || '';
    const errEl   = document.getElementById('abs-error');
    const showErr = msg => { if (errEl) { errEl.textContent = msg; errEl.style.display = ''; } };
    if (!fromVal || !toVal) { showErr('Please select both dates.'); return; }
    const today = new Date().toISOString().slice(0,10);
    if (fromVal < today) { showErr('From date must be today or later.'); return; }
    if (toVal < fromVal) { showErr('To date must be on or after from date.'); return; }
    const saveBtn = document.getElementById('abs-save');
    if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = 'Saving…'; }
    // Fetch existing for merge
    const { data: existing, error: fetchErr } = await sbL.from('kitchen_absences').select('*').eq('room', myRoom);
    if (fetchErr) {
      showErr('Could not save — ' + (fetchErr.message || 'please try again.'));
      if (saveBtn) { saveBtn.disabled = false; saveBtn.innerHTML = '<i class="ti ti-calendar-plus" style="font-size:14px;margin-right:6px;" aria-hidden="true"></i>Save absence'; }
      return;
    }
    // Merge overlapping/adjacent
    const dayAfter  = d => { const x = new Date(d); x.setDate(x.getDate()+1); return x.toISOString().slice(0,10); };
    const dayBefore = d => { const x = new Date(d); x.setDate(x.getDate()-1); return x.toISOString().slice(0,10); };
    const overlapping = (existing||[]).filter(a => a.from_date <= dayAfter(toVal) && a.to_date >= dayBefore(fromVal));
    const allFrom = [fromVal, ...overlapping.map(a=>a.from_date)];
    const allTo   = [toVal,   ...overlapping.map(a=>a.to_date)];
    const mergedFrom = allFrom.reduce((a,b) => a<b?a:b);
    const mergedTo   = allTo.reduce((a,b) => a>b?a:b);
    const existingNote = overlapping.find(a=>a.note)?.note || null;
    const mergedNote   = noteRaw || existingNote;
    if (overlapping.length) {
      await sbL.from('kitchen_absences').delete().in('id', overlapping.map(a=>a.id));
    }
    const payload = { room: myRoom, from_date: mergedFrom, to_date: mergedTo };
    if (mergedNote) payload.note = mergedNote;
    const { error: insErr } = await sbL.from('kitchen_absences').insert(payload);
    if (saveBtn) { saveBtn.disabled = false; saveBtn.innerHTML = '<i class="ti ti-calendar-plus" style="font-size:14px;margin-right:6px;" aria-hidden="true"></i>Save absence'; }
    if (insErr) { showErr('Could not save — ' + (insErr.message || 'please try again.')); return; }
    absCloseModal('register');
    absOpenModal('list');
  } finally { _absSaveBusy = false; }
}

/* ── DELETE ─────────────────────────────────────────────────── */
async function absDeleteAbsence(id) {
  if (!sbL) return;
  await sbL.from('kitchen_absences').delete().eq('id', id);
  _absPopulateList();
  // Notify both tabs to re-render rotation — pass room so tenant view stays correct
  const _absRoom = (typeof currentRoom !== 'undefined' && currentRoom) ? currentRoom : undefined;
  if (typeof loadHouseCleaning === 'function') loadHouseCleaning(_absRoom);
}

/* ─────────────────────────────────────────────────────────────
   js/tab-cleaning-tenant.js  (TENANT)

   Layout changes (logic unchanged):
   - "Mark absence" button moved out of card body into action strip
   - Action strip (Mark absence + View absences) always visible below card
   - "Your next turn" callout added below card when turn is coming up
   - Absence sub-section notices remain inline below action strip
   ───────────────────────────────────────────────────────────── */

/* ── INJECT HTML ────────────────────────────────────────── */
document.getElementById('tab-cleaning').innerHTML = `
  <h1 class="cc-h1 cc-mb-24">House Cleaning</h1>

  <div class="cc-section" style="padding-top:0;">
    <p class="hc-section-title">This week</p>
    <div id="hc-next-turn"></div>
    <div id="hc-current-week"></div>
  </div>

  <div class="cc-section">
    <p class="hc-section-title">Rotation — all rooms</p>
    <div id="hc-rotation-list"></div>
  </div>

`;

/* ── HC ROTATION CONSTANTS (same as landlord) ───────────── */
const HC_ROTATION = ['Copenhagen','Paris','Los Angeles','New York','London','Oslo','Stockholm'];
const HC_W1_START = new Date('2026-01-05T00:00:00');


function _hcGetRoomList() {
  // Always use appRooms as source of truth — same logic as kitchen.
  // New rooms appear at their sort_order position immediately, no holdback.
  if (typeof appRooms !== 'undefined' && appRooms.length > 0) {
    return [...appRooms]
      .filter(r => r.active)
      .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0))
      .map(r => r.name);
  }
  return HC_ROTATION;
}



function _hcWeekIndex(d) {
  const now = d || new Date();
  if (now < HC_W1_START) return -1;
  return Math.floor((now - HC_W1_START) / (7 * 24 * 60 * 60 * 1000));
}

function _hcWeekInfo(idx) {
  if (idx < 0) return null;
  const rot   = _hcGetRoomList();
  const room  = rot[idx % rot.length];
  const pad   = n => String(n).padStart(2, '0');
  const fmtD  = dt => pad(dt.getDate()) + '.' + pad(dt.getMonth() + 1) + '.' + dt.getFullYear();
  const start = new Date(HC_W1_START.getTime() + idx * 7 * 24 * 60 * 60 * 1000);
  const end   = new Date(start.getTime() + 6 * 24 * 60 * 60 * 1000);
  end.setHours(23, 59, 59, 999);
  const daysLeft = Math.max(0, Math.ceil((end - new Date()) / (24 * 60 * 60 * 1000)));
  return { room, start, end, daysLeft, dateRange: fmtD(start) + ' – ' + fmtD(end), idx };
}

/* ── REALTIME ───────────────────────────────────────────── */
let _hcTenChannel = null;
function _hcTenSubscribe(room) {
  if (!sbL) return;
  if (_hcTenChannel) { sbL.removeChannel(_hcTenChannel); _hcTenChannel = null; }
  _hcTenChannel = sbL.channel('cleaning-tenant-rt')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'cleaning_weeks' }, async () => {
      loadHouseCleaning(room);
    })
    .on('postgres_changes', { event: '*', schema: 'public', table: 'kitchen_absences' }, async () => {
      loadHouseCleaning(room);
    })
    .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'rooms' }, async () => {
      if (typeof loadRoomsData === 'function') await loadRoomsData();
      loadHouseCleaning(room);
    })
    .subscribe();
}

/* ── MAIN LOAD ──────────────────────────────────────────── */
async function loadHouseCleaning(room) {

  const curIdx    = _hcWeekIndex(new Date());
  const rot       = _hcGetRoomList();
  const curInfo   = _hcWeekInfo(curIdx);
  const cyclePos  = ((curIdx % rot.length) + rot.length) % rot.length;
  const cycleStart= curIdx - cyclePos;

  /* ── Fetch cleaning_weeks + absences in parallel ── */
  let hcDoneMap = {};
  let absRows   = [];
  if (sbL) {
    const [doneRes, absRes] = await Promise.all([
      sbL.from('cleaning_weeks').select('week_index,room,status,done_at,done_by').eq('status','done'),
      sbL.from('kitchen_absences').select('room,from_date,to_date')
    ]);
    if (doneRes.data) doneRes.data.forEach(row => {
      const key = row.week_index + '_' + row.room;
      if (!hcDoneMap[key]) hcDoneMap[key] = { room: row.done_by || row.room, ts: row.done_at ? new Date(row.done_at).getTime() : Date.now() };
    });
    absRows = absRes.data || [];
  } else {
    for (let i = 0; i < rot.length; i++) {
      const si = cycleStart + i;
      const v  = S.get('hc_done_' + si, null);
      if (v) hcDoneMap[si + '_' + rot[i]] = v;
    }
  }

  const wDone    = curInfo ? (hcDoneMap[curIdx + '_' + curInfo.room] || null) : null;
  const isDone   = !!wDone;
  const isMyTurn = curInfo?.room === room;

  // Absences covering this week
  const curWStart = curInfo ? curInfo.start.toISOString().slice(0,10) : null;
  const curWEnd   = curInfo ? curInfo.end.toISOString().slice(0,10)   : null;
  const weekAbsences = curWStart ? absRows.filter(a => a.from_date <= curWEnd && a.to_date >= curWStart) : [];
  // Is the current week's assigned room itself absent?
  const isCurrentRoomAbsent = curInfo ? weekAbsences.some(a => a.room === curInfo.room) : false;

  /* ── "Your next turn" lookahead ── */
  let nextTurnHtml = '';
  if (!isMyTurn && curInfo) {
    // Find the next slot belonging to this room — search up to 2 full cycles ahead
    for (let offset = 1; offset <= rot.length * 2; offset++) {
      const futureIdx  = curIdx + offset;
      const futureInfo = _hcWeekInfo(futureIdx);
      if (futureInfo && futureInfo.room === room) {
        const pad  = n => String(n).padStart(2, '0');
        const fmtD = dt => pad(dt.getDate()) + '.' + pad(dt.getMonth() + 1);
        const rangeStr = fmtD(futureInfo.start) + ' – ' + fmtD(futureInfo.end) + '.' + futureInfo.end.getFullYear();
        const weeksLabel = offset === 1 ? 'next week' : `in ${offset} week${offset !== 1 ? 's' : ''}`;
        nextTurnHtml = `<div style="display:flex;align-items:center;gap:8px;padding:8px 10px;background:#EBF4FF;border:0.5px solid #90C2F5;border-radius:var(--cc-r-sm);margin-bottom:8px;">
          <i class="ti ti-calendar-due" style="font-size:14px;color:#185FA5;flex-shrink:0;" aria-hidden="true"></i>
          <span style="font-size:11px;color:#1A5896;">Your turn ${weeksLabel} · ${rangeStr}</span>
        </div>`;
        break;
      }
    }
  }

  /* ── "Your next turn" callout — rendered above the card ── */
  const ntEl = document.getElementById('hc-next-turn');
  if (ntEl) ntEl.innerHTML = nextTurnHtml;

  /* ── This week card ── */
  const cwEl = document.getElementById('hc-current-week');
  if (!curInfo) {
    if (ntEl) ntEl.innerHTML = '';
    cwEl.innerHTML = '<p class="cc-note">Not started yet.</p>';
  } else {
    cwEl.innerHTML = `
      <div class="hc-current-card${isDone ? ' hc-current-card--done' : ''}">
        <div class="hc-current-top">
          <span class="k-mob-status-chip ${isDone ? 'approved' : isCurrentRoomAbsent ? 'skipped' : isMyTurn ? 'pending' : 'not-your-turn'}">
            ${isDone ? '✓ Done' : isCurrentRoomAbsent ? '— Away' : isMyTurn ? 'Your turn' : '— Not your turn'}
          </span>
        </div>
        <div class="k-mob-week-body" style="margin-top:8px;">
          <div class="k-mob-week-left">
            <span class="k-mob-week-room">${esc(curInfo.room)}</span>
            <span class="k-mob-week-dates-sm">${curInfo.dateRange} · ${curInfo.daysLeft} day${curInfo.daysLeft !== 1 ? 's' : ''} left</span>
          </div>
          ${isMyTurn && !isDone
            ? `<button class="k-mob-wact blue" id="hc-done-btn" aria-label="Mark as done">
                 <i class="ti ti-check"></i><span>Done</span>
               </button>`
            : isDone
              ? `<div style="font-size:10px;color:var(--cc-stone);text-align:right;line-height:1.3;">${esc(wDone.room)}<br>${fmtTs(wDone.ts)}</div>`
              : ''
          }
        </div>
      </div>

      <!-- Action strip: always-visible absence buttons outside the card -->
      <div style="margin-top:8px;display:flex;gap:6px;">
        <button onclick="absOpenModal('register')" style="flex:1;height:34px;display:flex;align-items:center;justify-content:center;gap:5px;background:var(--cc-gold);border:none;border-radius:var(--cc-r-sm);color:#fff;font-size:10px;font-weight:600;letter-spacing:0.06em;text-transform:uppercase;cursor:pointer;font-family:inherit;">
          <i class="ti ti-calendar-plus" style="font-size:13px;" aria-hidden="true"></i>
          Mark absence
        </button>
        <button onclick="absOpenModal('list')" style="flex:1;height:34px;display:flex;align-items:center;justify-content:center;gap:5px;background:none;border:0.5px solid var(--cc-rule);border-radius:var(--cc-r-sm);color:var(--cc-taupe);font-size:10px;font-weight:500;letter-spacing:0.06em;text-transform:uppercase;cursor:pointer;font-family:inherit;">
          <i class="ti ti-list" style="font-size:13px;" aria-hidden="true"></i>
          View absences
        </button>
      </div>

      <!-- Week-absence notices below action strip -->
      ${weekAbsences.length ? `<div style="margin-top:6px;">` + weekAbsences.map(a => {
        const note = a.note ? ` · ${esc(a.note)}` : '';
        return `<div style="width:100%;display:flex;align-items:center;gap:8px;padding:7px 10px;background:var(--cc-notice-bg);border:0.5px solid var(--cc-notice-bdr);border-radius:var(--cc-r-sm);margin-bottom:6px;">
          <i class="ti ti-calendar-off" style="font-size:14px;color:#8C5A30;flex-shrink:0;" aria-hidden="true"></i>
          <span style="flex:1;font-size:11px;color:#8C5A30;">${esc(a.room)} is away this week${note}</span>
        </div>`;
      }).join('') + `</div>` : ''}`;

    /* Wire mark-done button */
    if (isMyTurn && !isDone) {
      document.getElementById('hc-done-btn')?.addEventListener('click', async () => {
        const ts = Date.now();
        const btn = document.getElementById('hc-done-btn');
        if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
        // Persist to cleaning_weeks — realtime will re-render for all
        if (sbL) {
          await sbL.from('cleaning_weeks').upsert({
            week_index: curIdx,
            room: curInfo.room,
            status: 'done',
            done_at: new Date(ts).toISOString(),
            done_by: room
          }, { onConflict: 'week_index,room' });
        }
        // Also write locally for offline fallback
        S.set('hc_done_' + curIdx, { room, ts });
        // Re-render immediately so this tenant sees update without waiting for realtime
        await loadHouseCleaning(room);
      });
    }
  }

  /* ── Rotation timeline ── */
  _renderHcRotation(cycleStart, cyclePos, hcDoneMap, absRows, room, rot);

  /* ── Start realtime if not already running ── */
  _hcTenSubscribe(room);
}

/* ── ROTATION STATE ─────────────────────────────────────── */
function _hcRotState({ isNow, isPast, isNext, slotDone, room, weekStart, absRows }) {
  // 1. Absence — overrides everything including now/next
  if (absRows && weekStart) {
    const wStart = weekStart.toISOString().slice(0, 10);
    const wEnd   = new Date(weekStart.getTime() + 6 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    if (absRows.some(a => a.room === room && a.from_date <= wEnd && a.to_date >= wStart)) return 'absent';
  }
  // 2. Vacant room
  if (isVacant(room)) return 'skipped';
  // 3. Done — check before isNow so current week shows done correctly
  if (slotDone) return 'done';
  // 4. Current week, not done yet
  if (isNow) return 'now';
  // 5. Immediate next slot
  if (isNext) return 'next';
  // 6. Past week, no done = missed
  if (isPast) return 'missed';
  // 7. Future beyond next
  return 'upcoming';
}

/* ── ROTATION TIMELINE ──────────────────────────────────── */
function _renderHcRotation(cycleStart, cyclePos, hcDoneMap, absRows, myRoom, rot) {
  rot = rot || _hcGetRoomList();
  const rotEl = document.getElementById('hc-rotation-list');
  const pad   = n => String(n).padStart(2, '0');
  const fmtD  = dt => pad(dt.getDate()) + '.' + pad(dt.getMonth() + 1) + '.' + dt.getFullYear();

  let trueNextI = -1;
  for (let offset = 1; offset <= rot.length; offset++) {
    const candidateI    = (cyclePos + offset) % rot.length;
    const candidateSlot = cycleStart + cyclePos + offset;
    const candidateRoom = rot[candidateI];
    const candidateWs   = new Date(HC_W1_START.getTime() + candidateSlot * 7 * 24 * 60 * 60 * 1000);
    const candidateWe   = new Date(candidateWs.getTime() + 6 * 24 * 60 * 60 * 1000);
    const cwStart = candidateWs.toISOString().slice(0, 10);
    const cwEnd   = candidateWe.toISOString().slice(0, 10);
    const isAbsent  = (absRows || []).some(a => a.room === candidateRoom && a.from_date <= cwEnd && a.to_date >= cwStart);
    const isSkipped = isVacant(candidateRoom);
    if (!isAbsent && !isSkipped) { trueNextI = candidateI; break; }
  }

  rotEl.innerHTML = '<div class="rot-tl">' + rot.map((r, i) => {
    const slotIdx  = (i === trueNextI && trueNextI < cyclePos)
      ? cycleStart + rot.length + i
      : cycleStart + i;
    const ws       = new Date(HC_W1_START.getTime() + slotIdx * 7 * 24 * 60 * 60 * 1000);
    const we       = new Date(ws.getTime() + 6 * 24 * 60 * 60 * 1000);
    const dateStr  = fmtD(ws) + ' – ' + fmtD(we);
    const isPast   = i < cyclePos;
    const isNow    = i === cyclePos;
    const isNext   = i === trueNextI;
    const slotDone = hcDoneMap[(cycleStart + i) + '_' + r] || null;

    const state = _hcRotState({ isNow, isPast, isNext, slotDone, room: r, weekStart: ws, absRows: absRows || [] });

    const rowClass = 'rot-tl-row'
      + (state === 'now'     ? ' rot-tl-row--now'     : '')
      + (state === 'next'    ? ' rot-tl-row--next'    : '')
      + (state === 'missed'  ? ' rot-tl-row--missed'  : '')
      + (state === 'skipped' ? ' rot-tl-row--skipped' : '')
      + (state === 'absent'  ? ' rot-tl-row--absent'  : '');

    const dotClass = {
      done:'rot-dot--done', now:'rot-dot--now', next:'rot-dot--next',
      missed:'rot-dot--missed', skipped:'rot-dot--skipped', absent:'rot-dot--absent'
    }[state] || 'rot-dot--none';

    const topLine = state === 'done' || state === 'now' ? 'rot-line-done'
                  : state === 'skipped' ? 'rot-line-skipped'
                  : state === 'absent'  ? 'rot-line-absent'
                  : state === 'missed'  ? 'rot-line-missed'
                  : 'rot-line-faded';
    const botLine = state === 'done' && i < cyclePos ? 'rot-line-done' : 'rot-line-faded';

    const badge = {
      done:     '<span class="rot-badge rot-badge--done">Done</span>',
      now:      '<span class="rot-badge rot-badge--now">This week</span>',
      next:     '<span class="rot-badge rot-badge--next">Next</span>',
      missed:   '<span class="rot-badge rot-badge--missed">Missed</span>',
      skipped:  '<span class="rot-badge rot-badge--skipped">Skipped</span>',
      absent:   '<span class="rot-badge rot-badge--absent">Away</span>',
      upcoming: '<span class="rot-badge rot-badge--none">—</span>',
    }[state] || '<span class="rot-badge rot-badge--none">—</span>';

    /* "you" label on the tenant's own room rows */
    const youTag = (myRoom && r === myRoom)
      ? `<span style="font-size:9px;font-weight:600;color:var(--cc-gold);margin-left:4px;letter-spacing:0.06em;">you</span>`
      : '';

    return `<div class="${rowClass}">
      <div class="rot-spine">
        <div class="rot-spine-top ${topLine}"></div>
        <div class="rot-dot ${dotClass}"></div>
        <div class="rot-spine-bot ${botLine}"></div>
      </div>
      <div class="rot-tl-body">
        <div class="rot-tl-info">
          <p class="rot-tl-room">${r}${youTag}</p>
          <p class="rot-tl-dates">${dateStr}</p>
        </div>
        ${badge}
      </div>
    </div>`;
  }).join('') + '</div>';

  if (typeof onRoomsChange === 'function' && !loadHouseCleaning._roomsWired) {
    loadHouseCleaning._roomsWired = true;
    onRoomsChange(() => loadHouseCleaning(room));
  }
}
